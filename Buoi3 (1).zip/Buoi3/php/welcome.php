
<html>
<body>

Hello <?php echo $_POST["name"]; ?><br>
Your email address is: <?php echo $_POST["email"]; ?> <br>
 Your Password address is:       <?php echo $_POST["password"]; ?> <br>
 Your Ngay_Sinh address is:       <?php echo $_POST["ngay_sinh"]; ?>
</body>
</html>


