
<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Password <input type="password" name="password"> <br>
Ngay_sinh <input type="text" name ="ngay_sinh"> <br>
<input type="submit">
</form>

</body>
</html>